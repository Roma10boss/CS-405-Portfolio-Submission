#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length]; // XOR encryption
    }

    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    size_t pos = string_data.find('\n');
    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);

    file << student_name << std::endl; // Line 1: student name

    // Using localtime_s instead of localtime
    std::time_t now = std::time(nullptr);
    struct tm timeInfo;
    localtime_s(&timeInfo, &now);
    char buffer[80];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d", &timeInfo);

    file << buffer << std::endl; // Line 2: timestamp
    file << key << std::endl; // Line 3: key used
    file << data; // Line 4+: data

    file.close();
}


int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    const std::string student_name = get_student_name(source_string);

    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}
